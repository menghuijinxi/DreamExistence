﻿using System;

namespace DreamExistence.Network
{
    /// <summary>
    /// 所有网络操作均继承此类，这里实现了所有基础的网络操作方法
    /// </summary>
    public class Network
    {
    }
}
