﻿using System;
using System.Net;

namespace DreamExistence.Network
{
    /// <summary>
    /// 客户端，用于向服务器接收和发送数据
    /// </summary>
    public class Client : Network, IDisposable
    {
        private IPEndPoint _serverIP = null;

        /// <summary>
        /// 通过给定的终结节点连接一个服务器，对象会先被实例化出来，但是并不代表连接成功
        /// </summary>
        /// <param name="ip"></param>
        public Client(IPEndPoint ip)
        {
            _serverIP = ip;
            Connect();
        }

        /// <summary>
        /// 连接服务器
        /// </summary>
        public void Connect()
        {
 
        }

        /// <summary>
        /// 连接服务器
        /// </summary>
        /// <param name="ip"></param>
        public void Connect(IPEndPoint ip)
        {
 
        }

        /// <summary>
        /// 实现对客户端类的释放操作
        /// </summary>
        public void Dispose()
        {
            
        }
    }
}
