﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;

namespace DreamExistence.Network
{
    /// <summary>
    /// 服务端，主机应实例化该类，来与其他客户端通讯
    /// </summary>
    public class Server : Network, IDisposable
    {
        /// <summary>
        /// 局域网内的所有IP
        /// </summary>
        public List<IPAddress> IPLANs {private set;get;}

        /// <summary>
        /// 获取所有加入到游戏的玩家，下标为0的是主机玩家
        /// </summary>
        private List<Player> Players;
        /// <summary>
        /// 玩家对应的IP地址
        /// </summary>
        private List<IPEndPoint> PlayersIP;

        /// <summary>
        /// 所有黑名单用户
        /// </summary>
        private List<BlackList> _blackList;

        /// <summary>
        /// 服务端连接
        /// </summary>
        public Socket ServerSocket { set; get; }

        /// <summary>
        /// 获取主机玩家的信息
        /// </summary>
        //public Player GetPlayerHost { get { return Players[0]; } }

        /// <summary>
        /// 自动使用一个IP和空闲的端口初始化一个Server对象
        /// </summary>
        public Server()
        {
            ////创建Udp连接
            //Server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Udp);
            //PlayersIP = new List<IPEndPoint>();

            //Players = new List<Player>();
            //Players.Add(ObjectManager.GetObjectManager.PlayerHost);  //加入主机玩家

            ////添加主机IP
            //System.Threading.Mutex mutex = new System.Threading.Mutex();
            //mutex.WaitOne();
            //PlayersIP.Add(GetIPPort());
            //mutex.ReleaseMutex();

            ////绑定IP和端口
            //Server.Bind(PlayersIP[0]);

            #region 暂时无用的代码
            //    //获取当前计算机的名字
            //    string hostname = Dns.GetHostName();
            //    //获取所有IP地址
            //    IPAddress[] ips = Dns.GetHostAddresses(hostname);
            //    //使用的IP地址，用于多人游戏的初始化
            //    IPAddress ip = null;
            //    foreach (IPAddress item in ips)
            //    {
            //        //如果不是IP6协议就获取这个IP
            //        if (!item.IsIPv6LinkLocal)
            //        {
            //            ip = item;
            //            break;
            //        }
            //    }           

            //    System.Threading.Mutex mutex = new System.Threading.Mutex();
            //    mutex.WaitOne();

            //    try
            //    {
            //        //获取所有UDP监控的端口
            //        IPGlobalProperties ipglobal = IPGlobalProperties.GetIPGlobalProperties();
            //        IPEndPoint[] ipendponint = ipglobal.GetActiveUdpListeners();

            //        bool n = true;
            //        Random random = new Random();
            //        int port = 1001;
            //        while (n)
            //        {
            //            foreach (IPEndPoint item in ipendponint)
            //            {
            //                if (item.Port == port)
            //                {
            //                    n = true;
            //                }
            //                else
            //                    n = false;
            //            }
            //        }

            //        if (ip == null)
            //        {
            //            throw new Exception("未连接网络");
            //        }
            //    }
            //    catch
            //    { }
            //    finally
            //    {
            //        mutex.ReleaseMutex();
            //    }
            #endregion
        }

        /// <summary>
        /// 通过给定的终结节点初始化一个Server对象
        /// </summary>
        /// <param name="ip"></param>
        public Server(IPEndPoint ip)
        {
 
        }

        #region 公共方法

        /// <summary>
        /// 迭代返回局域网中的所有主机，这个方法速度很慢
        /// </summary>
        /// <returns></returns>
        public IEnumerable<IPAddress> GetLANIP()
        {
            //获取网段
            string segment = GetIP().ToString(); //PlayersIP[0].ToString();
            
            segment = segment.Remove(segment.LastIndexOf('.'));

            //创建ping对象
            Ping ping = new Ping();

            //Ping当前网段中的所有IP
            for (int i = 1; i <= 255; i++)
            {
                IPAddress ip = IPAddress.Parse(String.Format("{0}.{1}", segment, i.ToString()));
                PingReply pingReply = ping.Send(ip);

                if (pingReply.Status == IPStatus.Success)
                {
                    yield return ip;
                }
            }
        }

        /// <summary>
        /// 请求加入连接
        /// </summary>
        /// <param name="plyer"></param>
        /// <returns></returns>
        public bool AddPlayer(Player plyer)
        {
            return true;
        }

        /// <summary>
        /// 获取局域网内的所有主机
        /// </summary>
        public void GetLANIPAll()
        {
            //如果IPLANs属性为空就实例化它
            if (IPLANs == null)
                IPLANs = new List<IPAddress>();

            IPAddress[] ips = GetIPAll(); //获取本机的所有IP4网络
            string[] str = new string[ips.Length]; //该字符数组用于存储网段
            //将IP转换成网段
            for (int i = 0; i < ips.Length; i++)
            {
                str[i] = ips[i].ToString().Remove(ips[i].ToString().LastIndexOf('.'));
            }

            for (int j = 0; j < str.Length; j++)
            {
                //Ping当前网段中的所有IP
                for (int i = 1; i <= 255; i++)
                {
                    //创建ping对象
                    Ping ping = new Ping();
                    //转换IPAddress对象
                    IPAddress ip = IPAddress.Parse(String.Format("{0}.{1}", str[j], i.ToString()));
                    //添加回调函数
                    ping.PingCompleted += ping_PingCompleted;
                    //异步Ping目标地址
                    ping.SendAsync(ip, 2000, null);
                }
            }
        }

        /// <summary>
        /// 实现对服务端类的回收操作
        /// </summary>
        public void Dispose()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region 静态方法
        /// <summary>
        /// 获取本机一个空闲的端口
        /// </summary>
        /// <returns></returns>
        public static int GetPort()
        {
            //获取所有UDP监控的端口
            IPGlobalProperties ipglobal = IPGlobalProperties.GetIPGlobalProperties();
            IPEndPoint[] ipendponint = ipglobal.GetActiveUdpListeners();

            bool n = true;
            Random random = new Random();
            int port = 1024;
            while (n)
            {
                foreach (IPEndPoint item in ipendponint)
                {
                    if (item.Port == port)
                    {
                        n = true;
                    }
                    else
                        n = false;
                }

                if (n)
                    port++;
            }

            return port;
        }

        /// <summary>
        /// 获取本机的IP
        /// </summary>
        /// <returns></returns>
        public static IPAddress GetIP()
        {
            //获取当前计算机的名字
            string hostname = Dns.GetHostName();
            //获取所有IP地址
            IPAddress[] ips = Dns.GetHostAddresses(hostname);
            IPAddress ip = null;
            foreach (IPAddress item in ips)
            {
                //如果不是IP6协议就获取这个IP
                if (!item.IsIPv6LinkLocal)
                {
                    ip = item;
                    break;
                }
            }

            return ip;
        }

        public static IPAddress[] GetIPAll()
        {
            string hostname = Dns.GetHostName();
            List<IPAddress> ip = new List<IPAddress>();


            IPAddress[] ips = Dns.GetHostAddresses(hostname);

            foreach (var item in ips)
            {
                if (!item.IsIPv6LinkLocal && !item.IsIPv6Multicast && !item.IsIPv6SiteLocal)
                    ip.Add(item);
            }

            return ip.ToArray();
        }

        /// <summary>
        /// 获取一个空闲的IP段包含端口
        /// </summary>
        /// <returns></returns>
        public static IPEndPoint GetIPPort()
        {
            return new IPEndPoint(GetIP(), GetPort());
        }

        /// <summary>
        /// 迭代返回局域网中的所有主机
        /// </summary>
        /// <param name="ip"></param>
        /// <returns></returns>
        public static IEnumerable<IPAddress> GetLANIP(IPAddress ip)
        {
            //获取网段
            string segment = ip.ToString();
            segment = segment.Remove(segment.LastIndexOf('.'));

            //创建ping对象
            Ping ping = new Ping();
            //Ping当前网段中的所有IP
            for (int i = 1; i <= 255; i++)
            {
                IPAddress v_ip = IPAddress.Parse(String.Format("{0}.{1}", segment, i.ToString()));
                
                //ping.PingCompleted += 
                ping.SendAsync(v_ip, 2000, null);

                //if (pingReply.Status == IPStatus.Success)
                //{
                //    yield return v_ip;
                //}
            }

            return null;
        }
        #endregion

        #region 私有方法
        /// <summary>
        /// GetLANIPAll方法用的回调函数
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void ping_PingCompleted(object sender, PingCompletedEventArgs e)
        {
            if(e.Reply.Address.ToString() != "0.0.0.0")
                IPLANs.Add(e.Reply.Address);
        }
        #endregion
    }

    /// <summary>
    /// 黑名单
    /// </summary>
    public struct BlackList
    {
 
    }
}
