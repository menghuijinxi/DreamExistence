﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using DreamExistence.Network;

namespace DreamExistence
{
    /// <summary>
    /// 储存玩家所有信息的类
    /// </summary>
    public class Player
    {
        #region 私有字段和属性
        /// <summary>
        /// 玩家名字，请不要直接使用字段
        /// </summary>
        private string _name;
        /// <summary>
        /// 设置玩家左手拿着的武器，请不要直接调用字段
        /// </summary>
        private Weapon _playerLeftHandHoldingItem = null;
        /// <summary>
        /// 设置玩家右手拿着的武器，请不要直接调用字段
        /// </summary>
        private Weapon _playerRightHandHoldingItem = null;
        /// <summary>
        /// 设置玩家是否在使用双手武器，请不要直接调用字段
        /// </summary>
        private bool _isBothHands = false;
        /// <summary>
        /// 玩家的物品栏
        /// </summary>
        private ItemBar[] _itemBars;
        /// <summary>
        /// 玩家的装备栏，从0到3，依次是头盔，铠甲，裤子，鞋子
        /// </summary>
        private ItemBar[] _equipmentBars;

        /// <summary>
        /// 玩家的实例
        /// </summary>
        protected Player _player;

        /// <summary>
        /// 设置玩家名字，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private string _Name 
        { 
            get { return _player._name; } 
            set { _player._name = value; } 
        }

        /// <summary>
        /// 设置玩家左手拿着的武器，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private Weapon _PlayerLeftHandHoldingItem
        {
            get { return _player._playerLeftHandHoldingItem; }
            set { _player.PlayerLeftHandHoldingItem = value; }
        }

        /// <summary>
        /// 置玩家右手拿着的武器，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private Weapon _PlayerRightHandHoldingItem
        {
            get { return _player._playerRightHandHoldingItem; }
            set { _player._playerRightHandHoldingItem = value; }
        }

        /// <summary>
        /// 设置玩家是否在使用双手武器，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private bool _IsBothHands
        {
            get { return _player._isBothHands; }
            set { _player._isBothHands = value; }
        }

        /// <summary>
        /// 玩家的物品栏，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private ItemBar[] _ItemBars 
        {
            set { _player._itemBars = value; }
            get { return _player._itemBars; }
        }

        /// <summary>
        /// 玩家的装备栏，从0到3，依次是头盔，铠甲，裤子，鞋子，任何情况下都请不要调用字段，一定要调用属性
        /// </summary>
        private ItemBar[] _EquipmentBars 
        {
            set { _player._equipmentBars = value; }
            get { return _player._equipmentBars; }
        }

        #endregion

        #region 公共属性
        /// <summary>
        /// 玩家的名字，长度小于等于24个字符，游戏中的字符使用UTF-16编码，因此无论任何语言的字符都是占用2个字节
        /// </summary>
        public string Name 
        {
            set
            {
                if (value.Length <= 24)
                    _Name = value;
                else
                    _Name = value.Substring(0, 24);
            }
            get
            {
                return _Name;
            }
        }

        /// <summary>
        /// 玩家的物品栏
        /// </summary>
        public ItemBar[] ItemBars 
        { 
            set { _ItemBars = value; }
            get { return _ItemBars; }
        }

        /// <summary>
        /// 玩家的装备栏，从0到3，依次是头盔，铠甲，裤子，鞋子
        /// </summary>
        public ItemBar[] EquipmentBars 
        {
            set { _EquipmentBars = value; }
            get { return _EquipmentBars; }
        }

        /// <summary>
        /// 玩家当前左手上拿的物品，设置这个属性可以改变游戏中玩家手上显示的物品，如果当前手上拿着双手武器该属性无法修改，获取值时则会得到双手武器的值
        /// </summary>
        public Weapon PlayerLeftHandHoldingItem
        {
            set 
            {
                if (!_IsBothHands)
                    _PlayerLeftHandHoldingItem = value;
            }
            get
            {
                if (!_IsBothHands)
                    return _PlayerLeftHandHoldingItem;
                else
                    return _PlayerRightHandHoldingItem;
            }
        }
        
        /// <summary>
        /// 玩家右手上所持物品
        /// </summary>
        public Weapon PlayerRightHandHoldingItem
        {
            set 
            {
                //如果是双手武器，清空左手的物品
                if (!value.IsSingleHand)
                {
                    _player._isBothHands = true;  //当前装备的是双手武器
                    TakeOffWeaponToBackpack(true);    //去除左手的武器到背包       
                }
                //为右手所持物品赋值
                _PlayerRightHandHoldingItem = value;
            }
            get
            {
                return _PlayerRightHandHoldingItem;
            }
        }
        #endregion


        public Player()
        {
            InitDate();
        }

        /// <summary>
        /// 是否初始化数据，该构造函数用于服务器初始化游戏用
        /// </summary>
        /// <param name="isInit">true为初始化数据，false为不初始化数据</param>
        public Player(bool isInit)
        {
            if (isInit)
            {
                InitDate();
            }
        }

        #region 公共方法
        /// <summary>
        /// 卸下武器到背包
        /// </summary>
        /// <param name="hand">true为左手，false为右手</param>
        /// <returns></returns>
        public void TakeOffWeaponToBackpack(bool hand)
        {
        }
        #endregion

        #region 私有方法
        private void InitDate()
        {
            _player = this;

            _ItemBars = new ItemBar[36];
            _EquipmentBars = new ItemBar[4];
        }
#endregion

        #region 虚方法

        /// <summary>
        /// 如果开启多人模式，该属性可获取玩家的IP地址，否则将该方法会返回null
        /// </summary>
        public virtual IPAddress GetIP()
        {
            return null;
        }

        /// <summary>
        /// 请求加入主机
        /// </summary>
        /// <param name="ip">主机IP</param>
        /// <returns>是否加入成功</returns>
        public virtual bool JoinHost(IPEndPoint ip)
        {
            return false;
        }

        /// <summary>
        /// 获取主机IP和端口
        /// </summary>
        /// <returns></returns>
        public virtual IPEndPoint GetHost()
        {
            return null;
        }

        #endregion
    }

    /// <summary>
    /// 当开启多人游戏模式，就实例化本类
    /// </summary>
    public class PlayerMulti : Player
    {
        /*
         *原理说明，
         *多人游戏时，客户端玩家会实例化一个Client对象，搜索主机并请求连接
         *主机玩家会实例化一个Server对象用于与客户端通讯，主机玩家同时也会实例化一个Client对象，这个对象是PlayerMulti类实际维护的对象，PlayerMulti类并不对Server类进行任何维护，只负责实例化Server对象
         *
         */

        private readonly Server _server = null;
        private readonly Client _client = null;

        /// <summary>
        /// 客户端对象，该对象用于与服务器进行通信
        /// </summary>
        public Client Client { get { return _client; } }

        /// <summary>
        /// 服务端对象，如果是主机用户则会初始化该对象，否则该对象为空
        /// </summary>
        public Server Server { get { return _server; } }

        /// <summary>
        /// 玩家的IP地址信息
        /// </summary>
        public IPAddress IP { private set; get; }

        /// <summary>
        /// 主机的IP地址和端口号
        /// </summary>
        public IPEndPoint IPHost { private set; get; }

        private PlayerMulti()
        {
        }

        /// <summary>
        /// 通过给定的玩家对象，ip，和是否创建服务端来创建一个网络玩家对象
        /// </summary>
        /// <param name="player">玩家对象</param>
        /// <param name="ip">如果该IP网络IP请设置isServer为false，如果是本地IP请设置isServer为True</param>
        /// <param name="isServer"></param>
        public PlayerMulti(Player player, IPEndPoint ip, bool isServer)
        {
            base._player = player;

            if (isServer)
            {
                _server = new Server(ip);
                _client = new Client(ip);
            }
            else
            {
                _client = new Client(ip);
            }
        }

        #region 重写后的方法
        /// <summary>
        /// 获取玩家的IP地址
        /// </summary>
        /// <returns>IP地址信息</returns>
        public override IPAddress GetIP()
        {
            return this.IP;
        }

        /// <summary>
        /// 请求加入主机
        /// </summary>
        /// <param name="ip">主机IP</param>
        /// <returns>是否加入成功</returns>
        public override bool JoinHost(IPEndPoint ip)
        {
            return false;
        }

        public override IPEndPoint GetHost()
        {
            return IPHost;
        }
        #endregion
    }

    /// <summary>
    /// 主机玩家类
    /// </summary>
    //public class PlayerHost : Player
    //{
    //    /// <summary>
    //    /// 主机的IP地址和端口号
    //    /// </summary>
    //    public IPEndPoint IP { private set; get; }

    //    /// <summary>
    //    /// 用于多人通讯的对象
    //    /// </summary>
    //    private Server _communication;

    //    public PlayerHost(Player player)
    //    {
    //        base._player = player;
    //        _communication = new Server();
    //    }

    //    #region 重写后的方法

    //    /// <summary>
    //    /// 获取玩家的IP地址
    //    /// </summary>
    //    /// <returns>IP地址信息</returns>
    //    public override IPEndPoint GetHost()
    //    {
    //        return this.IP;
    //    }
    //    #endregion
    //}
}
