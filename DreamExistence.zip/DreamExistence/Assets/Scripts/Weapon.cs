﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 武器的类
    /// </summary>
    public class Weapon
    {
        /// <summary>
        /// 武器在物品栏上显示的图片
        /// </summary>
        public int WeaponThumbnail { set; get; }

        /// <summary>
        /// 武器的模型
        /// </summary>
        public int WeaponModel { set; get; }

        /// <summary>
        /// 该武器是不是单手武器，单手武器可左右手各拿一把，双手武器会只能同时拿一把，如果不设定默认是单手武器
        /// </summary>
        public bool IsSingleHand { set; get; }

        /// <summary>
        /// 该武器的攻击力
        /// </summary>
        public int ATK { set; get; }

        //该武器的特殊效果

        public Weapon()
        {
            IsSingleHand = true;
        }

        /// <summary>
        /// 通过ID获取一个武器的实例
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static Weapon GetWeapon(int id)
        {
            return null;
        }
    }
}
