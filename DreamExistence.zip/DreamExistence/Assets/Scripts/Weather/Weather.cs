﻿using System;
using System.Collections.Generic;


namespace DreamExistence.Weather
{
    /// <summary>
    /// 所有天气类的基类
    /// </summary>
    public class Weather
    {
        //public List<Biome> Biome { set; get; }

        /// <summary>
        /// 在指定的区块内生成天气
        /// </summary>
        /// <param name="area"></param>
        public void Generate(AreaBlock area)
        {
 
        }
    }
}
