﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    public class ItemBar
    {
        //原理，将该脚本挂载到物品栏上，指定物品栏类型，脚本会自动获取物品栏的Text

        /// <summary>
        /// 该物品栏的类型
        /// </summary>
        public ItemBarType BarType{set;get;}

        /// <summary>
        /// 物品栏的ID
        /// </summary>
        public int ID { set; get; }

        /// <summary>
        /// 物品栏存储的物品的ID，ID为0代表没有物品
        /// </summary>
        public int ItemID { set; get; }

        /// <summary>
        /// 物品栏存储的当前物品的数量，该属性未写完，该属性受限于物品的累加上线
        /// </summary>
        public int ItemNumber { set; get; }

        protected ItemBar(ItemBarType type)
        {
            BarType = type;
        }
    }

    public enum ItemBarType
    { 
        /// <summary>
        /// 物品栏
        /// </summary>
        ItemBar,
        /// <summary>
        /// 头盔栏
        /// </summary>
        HelmetBar,
        /// <summary>
        /// 铠甲栏
        /// </summary>
        BreastplateBar,
        /// <summary>
        /// 裤子栏
        /// </summary>
        PantsBar,
        /// <summary>
        /// 鞋子栏
        /// </summary>
        ShoesBar,
        /// <summary>
        /// 合成栏
        /// </summary>
        SynthesisBar,
        /// <summary>
        /// 合成后的成品栏
        /// </summary>
        SynthesisCompleteBar
    }
}
