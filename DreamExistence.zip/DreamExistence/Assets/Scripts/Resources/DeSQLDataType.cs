﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// Resources/String目录下的所有XML文件均会被编译到此脚本内变成只读属性
    /// </summary>
    public class DeSQLDataType<T>
    {

    }
}
