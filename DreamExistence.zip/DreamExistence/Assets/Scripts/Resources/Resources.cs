﻿using System;

namespace DreamExistence
{
    public class Resources
    {

    }
}
