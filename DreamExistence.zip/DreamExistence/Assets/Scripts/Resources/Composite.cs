﻿using System;

namespace DreamExistence
{
    /// <summary>
    /// 复合类型，当一个节点下存在两个以上节点时会生成一个复合类型
    /// </summary>
    public class Composite
    {

        /// <summary>
        /// 所有种类的复合类型
        /// </summary>
        public enum CompositeType
        {
            /// <summary>
            /// 对称复合类型，当一个节点下存在两个或以上与此节点相同类型的节点时，会生成一个对称复合类型，可以通过其中一个获取到另外几个
            /// </summary>
            Symmetric,
            /// <summary>
            /// 自定义数据类型，此数据类型根据程序的树状自动生成一个树对象
            /// </summary>
            Custom
        }
    }
}
