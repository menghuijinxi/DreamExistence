﻿using System;
using System.Collections.Generic;

namespace DreamExistence
{
    /// <summary>
    /// 树结构的节点
    /// </summary>
    /// <typeparam name="TKey">键，用于访问值</typeparam>
    /// <typeparam name="TVlue">值</typeparam>
    public class TreeDictionary<TKey, TVlue>
    {
        /// <summary>
        /// 这个节点的值
        /// </summary>
        public TVlue Value { set; get; }

        /// <summary>
        /// 这个节点包含的子节点
        /// </summary>
        private Dictionary<TKey, TreeDictionary<TKey, TVlue>> ChildNode = new Dictionary<TKey, TreeDictionary<TKey, TVlue>>(0);

        /// <summary>
        /// 子节点的数量
        /// </summary>
        public int ChildCount { get { return ChildNode.Count; } }

        /// <summary>
        /// 父节点
        /// </summary>
        public TreeDictionary<TKey, TVlue> ParentNode { private set; get; }

        /// <summary>
        /// 获取或者设置指定节点
        /// </summary>
        /// <param name="name">节点名</param>
        /// <returns>获取到的节点</returns>
        public TreeDictionary<TKey, TVlue> this[TKey name]
        {
            set
            {
                ChildNode[name] = value;
            }
            get
            {
                return ChildNode[name];
            }
        }

        public TreeDictionary() { }

        public TreeDictionary(TVlue value, params Node[] nodes)
        {
            Value = value;

            foreach (var item in nodes)
            {
                AddChildNode(item.key, item.Value);
            }
        }

        /// <summary>
        /// 尝试获取节点
        /// </summary>
        /// <param name="name">节点名</param>
        /// <param name="value">节点</param>
        /// <returns>是否获取成功</returns>
        public bool TryGetValue(TKey name, out TreeDictionary<TKey, TVlue> value)
        {
            return ChildNode.TryGetValue(name, out value);
        }

        /// <summary>
        /// 添加一个新的节点，或者覆盖一个老的节点
        /// </summary>
        /// <param name="key">节点名</param>
        /// <param name="value">节点值</param>
        public void AddChildNode(TKey name, TreeDictionary<TKey, TVlue> value)
        {
            ChildNode[name] = value;
            value.ParentNode = this;
        }

        /// <summary>
        /// 删除一个已存的节点
        /// </summary>
        /// <param name="key">节点名</param>
        public bool RemoveChildNode(TKey name)
        {
            return ChildNode.Remove(name);
        }

        /// <summary>
        /// 清空所有子节点
        /// </summary>
        public void ClearChildNode()
        {
            ChildNode.Clear();
        }

        /// <summary>
        /// 获取所有节点
        /// </summary>
        public Dictionary<TKey, TreeDictionary<TKey, TVlue>>.ValueCollection NodeValues { get { return ChildNode.Values; } }

        /// <summary>
        /// 获取所有节点的键
        /// </summary>
        public Dictionary<TKey, TreeDictionary<TKey, TVlue>>.KeyCollection NodeKeys { get { return ChildNode.Keys; } }

        /// <summary>
        /// 通过一组键获取到节点，如果中间的任意一个TKey没有子节点，就返回null
        /// </summary>
        /// <param name="searchSequence">一组TKey</param>
        /// <returns></returns>
        public TreeDictionary<TKey, TVlue> Find(IList<TKey> searchSequence)
        {
            var data = this;

            foreach (var item in searchSequence)
            {
                if (!data.TryGetValue(item, out data))
                {
                    return null;
                }
            }

            return data;
        }

        /// <summary>
        /// 通过一组键找到一个节点，并删除它
        /// </summary>
        /// <returns>是否成功删除</returns>
        public bool Remove(IList<TKey> searchSequence)
        {
            var data = Find(searchSequence);

            if (data != null)
            {
                return data.ParentNode.RemoveChildNode(searchSequence[searchSequence.Count - 1]);
            }
            else
                return false;
        }

        /// <summary>
        /// 通过一组键删除一组节点，删除是从后往前的，在第一个不符合条件的节点处会停止删除操作，如果查找不到节点，也会停止删除
        /// </summary>
        /// <param name="searchSeqience">一组键</param>
        /// <param name="condition">删除的条件</param>
        /// <returns>删除的节点的个数</returns>
        public int RemoveAll(IList<TKey> searchSeqience, RemoveCondition condition)
        {
            var node = Find(searchSeqience);

            //如果没有查找到节点，就返回0
            if (node == null)
                return 0;
            else
            {
                //删除掉第一个节点
                var parentNode = node.ParentNode;
                node.ParentNode.RemoveChildNode(searchSeqience[searchSeqience.Count - 1]);
                node = parentNode;

                int removeNumber = 1;

                for (int i = searchSeqience.Count - 2; i >= 0; i--)
                {
                    parentNode = node.ParentNode;

                    //查看是否符合删除条件
                    if (condition(node))
                    {
                        //删除节点
                        node.ParentNode.RemoveChildNode(searchSeqience[i]);
                        removeNumber++;
                    }
                    else
                        return removeNumber;

                    node = parentNode;
                }

                return removeNumber;
            }
        }

        /// <summary>
        /// 通过一组键创建一组节点，并返回最后创建的一个节点。如果节点存在则不创建
        /// </summary>
        /// <param name="keyList">一组键</param>
        /// <returns>最后创建的一个节点</returns>
        public TreeDictionary<TKey, TVlue> AddRange(IList<TKey> keyList)
        {
            var data = this;
            foreach (var item in keyList)
            {
                if (!data.TryGetValue(item, out data))
                {
                    var value = new TreeDictionary<TKey, TVlue>();
                    data[item] = value;
                    data = value;
                }
            }

            return data;
        }

        /// <summary>
        /// 删除一组节点时，需要遵循的删除规则
        /// </summary>
        /// <param name="deletedNode"></param>
        /// <returns></returns>
        public delegate bool RemoveCondition(TreeDictionary<TKey, TVlue> deletedNode);

        public struct Node
        {
            /// <summary>
            /// 键
            /// </summary>
            public TKey key { set; get; }
            /// <summary>
            /// 值
            /// </summary>
            public TreeDictionary<TKey, TVlue> Value { set; get; }
        }
    }
}