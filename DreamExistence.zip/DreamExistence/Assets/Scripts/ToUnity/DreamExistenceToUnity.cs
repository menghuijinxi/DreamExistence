﻿using System;

namespace DreamExistence
{
    /// <summary>
    /// 这个类负责与Unity通讯
    /// </summary>
    public class DreamExistenceToUnity
    {

    }
}
