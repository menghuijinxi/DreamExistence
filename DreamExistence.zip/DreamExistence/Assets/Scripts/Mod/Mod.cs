﻿using System;

namespace DreamExistence
{
    /// <summary>
    /// Mod类，此类用于实例化一个Mod到游戏中，每个Mod均为一个后缀为.mod的zip压缩包，是此编辑器生成出来的
    /// Mod是游戏功能的基本构成，所有扩展功能均通过Mod推出
    /// 所有Mod均继承此类
    /// 此类是每个Mod的入口
    /// </summary>
    public class Mod : GameObject
    {
        /// <summary>
        /// 通过路径安装一个Mod
        /// </summary>
        /// <returns></returns>
        public static bool Install(string path)
        {
            return true;
        }

        /// <summary>
        /// 通过文件流安装一个Mod
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public static bool Install(System.IO.Stream stream)
        {
            return true;
        }

        /// <summary>
        /// 卸载一个Mod
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static bool Uninstall(string name)
        {
            return true;
        }

        #region 静态成员
        /// <summary>
        /// 获取Mod文件夹下所有可使用的Mod路径
        /// </summary>
        /// <returns></returns>
        public static string[] GetModPath()
        {
            return null;
        }

        private static System.Collections.Generic.List<System.Reflection.Assembly> _registerAssembly = new System.Collections.Generic.List<System.Reflection.Assembly>(1);

        /// <summary>
        /// 获取所有已注册的程序集
        /// </summary>
        /// <returns></returns>
        public static System.Reflection.Assembly[] GetRegisterAssembly()
        {
            return _registerAssembly.ToArray();
        }
        #endregion
    }
}
