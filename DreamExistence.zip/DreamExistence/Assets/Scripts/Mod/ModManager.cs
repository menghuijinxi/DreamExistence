﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// Mod管理器
    /// </summary>
    public class ModManager : Manager<Mod>
    {
        private List<Mod> _mods;

        public ModManager()
        {
            _mods = new List<Mod>();
        }

        protected override void Initial(DreamExistence.Object obj)
        {
            if (obj is Mod)
            {
                _mods.Add((Mod)obj);
            }
        }
    }
}
