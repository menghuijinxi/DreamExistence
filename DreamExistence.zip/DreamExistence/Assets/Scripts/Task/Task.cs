﻿using System;

namespace DreamExistence
{
    /// <summary>
    /// 任务管理类，这里处理所有任务的管理
    /// </summary>
    public class TaskManager
    {
    }

    /// <summary>
    /// 任务节点，每一个任务包括任务中的每一步任务节点均是Task对象
    /// </summary>
    public class Task : ITask
    {

    }

    /// <summary>
    /// 如果你需要创建一个自定义的任务类，需要继承并实现此接口，并且选择性的继承Task类，继承Task可以帮你节省一些工作量
    /// </summary>
    public interface ITask
    {

    }
}
