﻿using System;
using System.Collections.Generic;

namespace DreamExistence
{
    /// <summary>
    /// 包含所有存档操作的类，此类已封装所有类型存档格式，且实现了高效的数据储存和读取
    /// </summary>
    public sealed class SaveSQL : Manager<ISave>
    {
        private List<ISave> _save;

        //这个类不继承ISave接口，这里只处理继承了ISave接口的对象
        public SaveSQL()
        {
            _save = new List<ISave>();
        }

        /// <summary>
        /// 调用此方法，会调用所有继承了ISave接口并且继承了Object类的Save方法
        /// </summary>
        public static void Save()
        {
            SaveSQL save = ObjectManager.GetObjectManager.Save;

            foreach (var item in save._save)
            {
                if (item == null)
                    save._save.Remove(item);
                else
                    item.Save();
            }
        }

        /// <summary>
        /// 继承了IGUI接口并继承过Object类后，在对象初始化时会自动执行该方法
        /// </summary>
        /// <param name="obj"></param>
        protected override void Initial(DreamExistence.Object g)
        {
            if (g is ISave)
            {
                _save.Add((ISave)g);
            }
        }
    }

    /// <summary>
    /// 所有存档类均继承该接口，所有继承ISave接口的类在调用SaveSQL.Save()后均会被调用Save方法，请在Save方法修改存档规则，包括这次存档是否要执行
    /// </summary>
    public interface ISave
    {
        void Save();
    }

    /// <summary>
    /// 如果想自定义一个地形存档类，请继承该接口
    /// </summary>
    public interface ITerrainSave : ISave
    {

    }

    /// <summary>
    /// 如果想自定义一个玩家存档类，请继承该接口
    /// </summary>
    public interface IPlayerSave : ISave
    {

    }

    /// <summary>
    /// 如果想自定义一个容器的存档类，请继承该接口
    /// </summary>
    public interface IContainer : ISave
    {

    }

    /// <summary>
    /// 如果想自定义一个生物的存档类，请继承该接口
    /// </summary>
    public interface IBiology : ISave
    {

    }

    /// <summary>
    /// 如果想自定义一个选项菜单的配置存档类，请继承该接口
    /// </summary>
    public interface IConfigs : ISave
    {

    }
}
