﻿using System;
using System.Collections.Generic;
using System.IO;
using DreamExistence;
using System.Xml;

public class ObjectManager : Manager<DreamExistence.Object>
{
    /// <summary>
    /// 所有游戏对象
    /// </summary>
    private List<DreamExistence.Object> _object;

    private int _seed;   //种子

    //所有需要使用的方块的贴图
    //所有实例化的方块的对象池
    //所有物品在物品栏显示图
    //所有3D模型
    //需要使用的武器，装备，道具的基本信息

    /// <summary>
    /// 当前类的实例
    /// </summary>
    public static ObjectManager GetObjectManager = new ObjectManager();

    /// <summary>
    /// 主机玩家
    /// </summary>
    public Player PlayerHost { set; get; }

    /// <summary>
    /// 进行一些存档操作的对象
    /// </summary>
    public SaveSQL Save { private set; get; }

    /// <summary>
    /// 已实例化的天气系统
    /// </summary>
    public List<DreamExistence.Weather.Weather> Weather { set; get; }

    /// <summary>
    /// 游戏的种子
    /// </summary>
    public int Seed 
    {
        get 
        {
            return _seed;
        }
    }

    private ObjectManager()
    {
        _object = new List<DreamExistence.Object>();

        //告诉系统种子处于未初始化状态
        _seed = -1;

        Weather = new List<DreamExistence.Weather.Weather>();

        Save = new SaveSQL();
        
    }

    /// <summary>
    /// 初始化类
    /// </summary>
    /// <param name="obj"></param>
    protected override void Initial(DreamExistence.Object obj)
    {
        if (obj is DreamExistence.Object)
        {
            _object.Add(obj);
        }
    }

    /// <summary>
    /// 这个方法用于初始化Seed的，是必须调用的。返回值为true证明读取成功，返回值为false证明已经读取过种子文件了
    /// </summary>
    /// <param name="path">种子文件</param>
    /// <returns></returns>
    public bool SetSeed(string path)
    {
        if (_seed == -1)
        {
            using (XmlReader read = XmlReader.Create(path))
            {
                while (read.Read())
                {
                    if (read.NodeType == XmlNodeType.Element)
                    {
                        //如果读取到首节点了将种子值读入
                        if (read.Name == "Block")
                        {
                            //读取种子
                            this._seed = int.Parse(read.GetAttribute(0));
                        }
                        else
                        {
                            int id = int.Parse(read.GetAttribute(1));
                            //获取区块ID看是否与List数组的索引相等
                            //if (id == _blockMessage.Count)
                            {
                                string[] positions = read.GetAttribute(0).Split(',');
                                //_blockMessage.Add(new UnityEngine.Vector3(int.Parse(positions[0]), int.Parse(positions[1])));
                            }
                        }
                    }
                }
            }

            return true;
        }
        else
        {
            return false;
        }
    }
}
