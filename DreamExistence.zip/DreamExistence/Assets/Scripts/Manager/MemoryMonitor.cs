﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 内存监控器
    /// </summary>
    public class MemoryMonitor
    {
    }
}
