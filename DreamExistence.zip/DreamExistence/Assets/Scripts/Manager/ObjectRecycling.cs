﻿
using System.Collections.Generic;

namespace DreamExistence
{
    /// <summary>
    /// 对一组对象进行回收再利用处理
    /// </summary>
    public class ObjectRecycling<T> where T : class
    {
        public ObjectRecycling()
        {
            MaxRecyclingNumber = 20;
            _objectList = new Queue<T>();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="number">初始化储存数量</param>
        public ObjectRecycling(int number)
        {
            MaxRecyclingNumber = 20;
            _objectList = new Queue<T>(number);
        }

        private Queue<T> _objectList;

        /// <summary>
        /// 回收对象的储存上线，默认20。回收上线小于等于零，回收则无上限
        /// </summary>
        public int MaxRecyclingNumber { set; get; }

        /// <summary>
        /// 回收一个对象
        /// </summary>
        /// <param name="ob">待回收的对象</param>
        /// <returns>是否回收成功</returns>
        public bool Recycling(T ob)
        {
            if (MaxRecyclingNumber > 0 && _objectList.Count >= MaxRecyclingNumber)
                return false;

            if (RecyclingEvent != null)
                RecyclingEvent(ob);

            _objectList.Enqueue(ob);
            return true;
        }

        /// <summary>
        /// 清空回收对象，保留一定数量，此方法是异步的
        /// </summary>
        /// <param name="eeservedNumber">需要保留的对象数量</param>
        public void ClearRecyclingAsync(int eeservedNumber)
        {
            System.Action act = () => {
                for (int i = _objectList.Count; i > eeservedNumber; i--)
                {
                    _objectList.Dequeue();
                }
            };

            act.BeginInvoke(null, null);
        }

        /// <summary>
        /// 获取一个对象
        /// </summary>
        /// <returns></returns>
        public T GetOjbect()
        {
            if (_objectList.Count == 0)
            {
                if(GetObjectNullEvent != null)
                    return GetObjectNullEvent();
                return null;
            }

            T value = _objectList.Dequeue();

            if (GetObjectEvent != null)
                GetObjectEvent(value);

            return value;
        }

        /// <summary>
        /// 对象回收后触发
        /// </summary>
        public event System.Action<T> RecyclingEvent;

        /// <summary>
        /// 获取到对象前触发
        /// </summary>
        public event System.Action<T> GetObjectEvent;

        public event System.Func<T> GetObjectNullEvent;
    }
}