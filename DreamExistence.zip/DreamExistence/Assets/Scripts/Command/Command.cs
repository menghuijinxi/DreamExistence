﻿using System;

namespace DreamExistence
{
    /// <summary>
    /// 游戏中的所有命令，如作弊命令等
    /// </summary>
    public class Command
    {
    }
}
