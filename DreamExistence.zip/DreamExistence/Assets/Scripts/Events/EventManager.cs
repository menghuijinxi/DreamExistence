﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence.Events
{
    /// <summary>
    /// 事件管理器
    /// </summary>
    public class EventManager
    {

    }
}
