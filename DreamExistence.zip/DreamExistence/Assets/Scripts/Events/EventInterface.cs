﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence.Events
{
    /// <summary>
    /// 当一个游戏物体需要响应鼠标右击该物体的事件时，继承此接口
    /// </summary>
    public interface IRightClickItem
    {
        void RightClick();
    }

    /// <summary>
    /// 当一个游戏物体需要响应鼠标左击该物体的事件时，继承此接口
    /// </summary>
    public interface ILeftClickItem
    {
        void LeftClick();
    }

    /// <summary>
    /// 当一个游戏物体能够放置到场景中时，继承此接口
    /// </summary>
    public interface IPutGameObject
    {
        void Put(UnityEngine.Vector3 position);
    }
}
