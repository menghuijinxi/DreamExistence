﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence.Events
{
    public delegate void PutGameObject(GameObject cube, UnityEngine.Vector3 position);
}
