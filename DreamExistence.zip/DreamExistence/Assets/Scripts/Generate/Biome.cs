﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 所有生态群系的基类
    /// </summary>
    public class Biome
    {
        private List<int> _GenerationCube;  //该生物群系会生成的方块
        private List<int> _GenerationBuildings; //该生物群系会生成的建筑物
        private List<int> _GenerationAnimal; //该生物群系会生成的动物，包块怪物
        private int[] _GenerationCubeMain = new int[3]; //该生物群系的主生成物，下标为0的是地形表层生成物，下标为1的是地形地层生成物，2是基岩层主生成物

        private List<DreamExistence.Weather.Weather> _weather;  //当前区块会产生的天气

        /// <summary>
        /// 该生物群系的最高生成高度
        /// </summary>
        public int MaxGenerationHeight { set; get; }

        protected Biome()
        {
            _GenerationCube = new List<int>();
            _GenerationAnimal = new List<int>();
            _GenerationBuildings = new List<int>();
            _weather = new List<Weather.Weather>(1);
        }

        /// <summary>
        /// 添加该区块生成的方块
        /// </summary>
        /// <param name="id"></param>
        /// <returns>是否添加成功，如果已经有该ID就会添加失败</returns>
        public bool AddCube(int id)
        {
            for (int i = 0; i < _GenerationCube.Count; i++)
            {
                if (_GenerationCube[i] == id)
                {
                    return false;
                }
            }

            _GenerationCube.Add(id);
            return true;
        }

        /// <summary>
        /// 删除该区块的生成物
        /// </summary>
        /// <param name="id"></param>
        /// <returns>删除是否成功，如果没有改ID删除会失败</returns>
        public bool RemoveCube(int id)
        {
            return _GenerationCube.Remove(id);
        }
    }
}
