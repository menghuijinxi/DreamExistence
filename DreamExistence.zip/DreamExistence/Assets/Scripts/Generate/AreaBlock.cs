﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 游戏中地形的一个单位
    /// </summary>
    public class AreaBlock : UnityEngine.Object
    {
        /// <summary>
        /// 修改过的方块
        /// </summary>
        private Dictionary<Vector3Int, int> _ModifiedCube;

        /// <summary>
        /// 修改了但未保存的方块
        /// </summary>
        private Dictionary<Vector3Int, int> _noSaveCube;

        /// <summary>
        /// 当前区块的生物群系
        /// </summary>
        public Biome LocationBiome { set; get; }

        /// <summary>
        /// 区块的首坐标
        /// </summary>
        public Vector2Int FirstCoordinate { set; get; }

        /// <summary>
        /// 区块是否被加载
        /// </summary>
        public bool IsLoad { set; get; }

        private AreaBlock()
        {
            _ModifiedCube = new Dictionary<Vector3Int, int>();
        }

        /// <summary>
        /// 通过首坐标初始化区块类，填写区块内的任意坐标也可以完成初始化
        /// </summary>
        /// <param name="first"></param>
        private AreaBlock(Vector2Int first) : this()
        {
            this.FirstCoordinate = GetFirstCoordinate(first);  //计算首坐标
        }

        /// <summary>
        /// 被加载的区块会每帧都执行一次该方法
        /// </summary>
        public void Update()
        {
            //如果区块被加载，就对区块内的行为进行处理
            if (IsLoad)
            {

            }
        }

        /// <summary>
        /// 获取坐标的方块的ID
        /// </summary>
        /// <param name="vector">坐标</param>
        /// <returns>物品的ID</returns>
        public int GetCoordinateCubeID(Vector3Int vector)
        {
            int id = -1;

            _ModifiedCube.TryGetValue(vector, out id);

            if (id != -1)
                return id;
            else
            {
                //return GenerationCoordinateCubeID(vector);
                return 0;
            }
        }

        /// <summary>
        /// 修改指定坐标的方块
        /// </summary>
        /// <param name="vector">坐标，请输入本区块的坐标</param>
        /// <param name="id">需要修改的方块的ID</param>
        public void SetModified(Vector3Int vector, int id)
        {
            //修改对应坐标的方块
            _ModifiedCube[vector] = id;
            _noSaveCube[vector] = id;
        }

        /// <summary>
        /// 删除对应坐标的方块,这个方法只在生成算法生成的方块和集合中对应的方块重合时调用，以达到减少内存的效果，并不回收对象
        /// </summary>
        /// <param name="vector"></param>
        public void RemoveModified(Vector3Int vector)
        {
            if (GetFirstCoordinate(vector) == this.FirstCoordinate)
            {
                //删除对应坐标的方块
                _ModifiedCube.Remove(vector);
            }
        }

        /// <summary>
        /// 获取该坐标的方块在当前区块的ID，请不要传入不是本区块的坐标，不然会返回-1
        /// </summary>
        /// <param name="vector"></param>
        public int GetCubeLocalID(Vector3Int vector)
        {
            if (GetFirstCoordinate(vector) == this.FirstCoordinate)
            {
                vector.ToAreaBlock();
                return vector.X << 13 + (vector.X + 1) * ((vector.Y - 1) << 4 + vector.Z);
            }

            return -1;
        }

        /// <summary>
        /// 判断坐标是否在当前区块内
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        public bool IsPositionInAreaBlock(Vector3Int vector)
        {
            if (GetFirstCoordinate(vector) == this.FirstCoordinate)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 从世界坐标转换成区块坐标
        /// </summary>
        /// <param name="vector">世界坐标</param>
        /// <returns>区块坐标</returns>
        public static Vector3Int WordToAreaBlock(Vector3Int vector)
        {
            return new Vector3Int(vector.X % 16, vector.Y, vector.Z % 16);
        }

        /// <summary>
        /// 获得当前坐标所在区块的首坐标
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public static Vector2Int GetFirstCoordinate(Vector2Int position)
        {
            return new Vector2Int(position.X >> 4 << 4, position.Z >> 4 << 4);
        }

        /// <summary>
        /// 获得当前坐标所在区块的首坐标
        /// </summary>
        /// <param name="position"></param>
        /// <returns></returns>
        public static Vector2Int GetFirstCoordinate(Vector3Int position)
        {
            return new Vector2Int(position.X >> 4 << 4, position.Z >> 4 << 4);
        }

        /// <summary>
        /// 创建一个区块
        /// </summary>
        /// <returns></returns>
        public static AreaBlock CreateAreaBlock()
        {
            return null;
        }

        #region 可能舍弃
        /// <summary>
        /// 生成给定的坐标的方块的ID
        /// </summary>
        /// <param name="vector"></param>
        /// <returns></returns>
        //private int GenerationCoordinateCubeID(Vector3Int vector)
        //{
        //    //通过当前区块的种子初始化随机数函数
        //    Random random = new Random(Seed);

        //    for (int i = LocationBiome.MaxGenerationHeight - vector.Y; i > 0; i--)
        //    {
        //        random.Next();
        //    }

        //    int seed = random.Next();

        //    Random random_ = new Random(seed);

        //    vector.ToAreaBlock();
        //    for (int i = 0; i < vector.X * 16 + vector.Z; i++)
        //    {
        //        random_.Next();
        //    }

        //    return random_.Next();
        //}
        #endregion
    }
}
