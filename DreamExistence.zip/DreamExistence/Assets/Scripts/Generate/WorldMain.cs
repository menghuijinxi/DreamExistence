﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 主世界
    /// </summary>
    public class WorldMain : WorldBasic
    {
        public WorldMain()
        {
            this.WorldRange = new Vector2Int(256, 511);
        }

        public override void LoadWord()
        {
            base.LoadWord();
        }
    }
}
