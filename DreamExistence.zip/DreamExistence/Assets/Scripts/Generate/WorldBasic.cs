﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 世界的基类
    /// </summary>
    public abstract class WorldBasic
    {
        /// <summary>
        /// 这个世界的种子
        /// </summary>
        public int Seed { protected set; get; }

        /// <summary>
        /// 世界的范围，高度影响世界
        /// </summary>
        public Vector2Int WorldRange { protected set; get; }

        public WorldBasic()
        {
            Seed = DateTime.Now.GetHashCode();
        }

        protected List<Biome> _biomeList = new List<Biome>();

        /// <summary>
        /// 整个世界的数据
        /// </summary>
        protected Dictionary<Vector2Int, AreaBlock> _wordData = new Dictionary<Vector2Int, AreaBlock>();

        /// <summary>
        /// 修改一个坐标的物体
        /// </summary>
        /// <param name="position">需要修改的坐标</param>
        public void Modify(Vector3Int position, int id)
        {
            AreaBlock ab = null;

            Vector2Int firstPosition = AreaBlock.GetFirstCoordinate(position);

            if (_wordData.TryGetValue(firstPosition, out ab))
                ab.SetModified(position, id);
            else
            {
                ab = AreaBlock.CreateAreaBlock();
                _wordData[firstPosition] = ab;
                ab.SetModified(position, id);
            }
        }

        /// <summary>
        /// 对未被加载的区块的内存进行清理
        /// </summary>
        public void ClearAreaBlock()
        {
            for (int i = _wordData.Count - 1; i >= 0; i++)
            {
                Vector2Int position = _wordData.Keys.ElementAt(i);
                AreaBlock ab = _wordData[position];

                //如果区块已经不被加载了，就释放掉区块占用的内存
                if(!ab.IsLoad)
                {
                    _wordData.Remove(position);
                    UnityEngine.Object.Destroy(ab);
                }
            }
        }

        /// <summary>
        /// 如何从存档中加载世界
        /// </summary>
        public virtual void LoadWord()
        {

        }

        /// <summary>
        /// 获取一个坐标的随机数
        /// </summary>
        /// <param name="position">获取用的坐标</param>
        /// <returns></returns>
        public float GetRandomNumber(Vector3Int position)
        {
            UnityEngine.Random.seed = position.GetHashCode() << 3 + Seed;

            return UnityEngine.Random.Range(0f, 1f);
        }
    }
}
