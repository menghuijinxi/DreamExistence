﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 游戏内的所有物体都继承自此类
    /// </summary>
    public class GameObject : UnityEngine.Object
    {
        /// <summary>
        /// 所有不同的物体都会拥有一个id，id相同则被认为是同一个物体
        /// </summary>
        public string ID
        {
            protected set;get;
        }

        /// <summary>
        /// 所有游戏物体均有一个名字，该名字用于在游戏中显示给玩家
        /// </summary>
        public new string name
        {
            set;get;
        }

        /// <summary>
        /// 该物体在游戏中的对象
        /// </summary>
        protected UnityEngine.GameObject _Object;

        /// <summary>
        /// 当前方块的对象
        /// </summary>
        public UnityEngine.GameObject Object
        {
            protected set { _Object = value; }
            get { return _Object; }
        }

        public GameObject(string id)
        {
            ID = id;
        }

        public GameObject(GameObjectInfo info) : this(info.ID)
        {
            name = info.Name;
        }

        protected GameObject() { }

        /// <summary>
        /// 有些游戏物体会有各种状态，此方法可以将状态和id合并返回出动态的唯一id，对物体进行整理时，以此方法获取的id来进行分类。
        /// </summary>
        /// <returns></returns>
        public virtual string ToID()
        {
            return ID;
        }
    }

    /// <summary>
    /// 游戏物体的基本信息
    /// </summary>
    public class GameObjectInfo
    {
        /// <summary>
        /// id
        /// </summary>
        public string ID { set; get; }
        /// <summary>
        /// 材质
        /// </summary>
        public UnityEngine.Material Material { set; get; }
        /// <summary>
        /// 名字
        /// </summary>
        public string Name { set; get; }

        /// <summary>
        /// 物品描述
        /// </summary>
        public string Description { set; get; }

        /// <summary>
        /// 获取物品的方法描述
        /// </summary>
        public string ObtainDescription { set; get; }
    }
}
