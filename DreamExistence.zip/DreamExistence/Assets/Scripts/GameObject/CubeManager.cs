﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 方块管理器
    /// </summary>
    public class CubeManager
    {
        
    }
}
