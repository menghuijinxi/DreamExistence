﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;

namespace DreamExistence
{
    /// <summary>
    /// 需要一个带GUI的方块就继承此类
    /// </summary>
    public class GUICube : Cube
    {
        //protected GUICube()
        //{

        //}

        //public GUICube(GUIType showType)
        //{
        //    ShowType = showType;
        //}

        /// <summary>
        /// GUI的显示方式
        /// </summary>
        public GUIType ShowType = GUIType.None;

        public GUICube(string id) : base(id)
        {
        }

        /// <summary>
        /// 显示GUI
        /// </summary>
        public void OpenGUI()
        {

        }

        /// <summary>
        /// GUI的显示方式
        /// </summary>
        public enum GUIType
        {
            /// <summary>
            /// 当为此值时，GUI将失效，没有反应
            /// </summary>
            None,
            /// <summary>
            /// 当为此值时，GUI以普通的方式显示在屏幕上
            /// </summary>
            GUI2D,
            /// <summary>
            /// 当为此值时，GUI以3DUI的方式显示在场景中
            /// </summary>
            GUI3D
        }
    }
}
