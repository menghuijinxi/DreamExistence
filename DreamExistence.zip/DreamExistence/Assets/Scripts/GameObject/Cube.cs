﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 游戏中大部分物体的基础单位
    /// </summary>
    public class Cube : GameObject, DreamExistence.Events.ILeftClickItem, DreamExistence.Events.IRightClickItem, DreamExistence.Events.IPutGameObject
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id">方块的id</param>
        /// <param name="material">方块的材质</param>
        public Cube(string id) : base(id) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info">方块的信息</param>
        public Cube(CubeInfo info) : base(info)
        {
            Durability = info.Durability;
            _info = info;
        }

        private CubeInfo _info;

        static Cube()
        {
            _cubeRecycling = new ObjectRecycling<UnityEngine.GameObject>();
            _cubeRecycling.MaxRecyclingNumber = -1;
        }

        /// <summary>
        /// 获取一个Cube的对象
        /// </summary>
        /// <returns>获取或者创建的新物体</returns>
        private UnityEngine.GameObject GetCube()
        {
            UnityEngine.GameObject go = _cubeRecycling.GetOjbect();

            if (go == null)
                go = UnityEngine.GameObject.CreatePrimitive(UnityEngine.PrimitiveType.Cube);

            go.GetComponent<UnityEngine.Renderer>().material = _info.Material;
            go.gameObject.SetActive(true);

            return go;
        }

        /// <summary>
        /// 一个Cube的硬度等级，硬度可以小于0，小于零的硬度就是柔然度，等于0的硬度是无敌的
        /// </summary>
        public int Hardness { set; get; }

        private int _durability = 0;
        /// <summary>
        /// 一个Cube的耐久值，此值决定方块的采掘速度，耐久值最低为0，如果耐久值默认为零，该方块只能承受一次左击
        /// </summary>
        public int Durability { protected set { _durability = value; } get { return _durability; } }

        /// <summary>
        /// 将当前方块放置到某处，此方法不用重写
        /// </summary>
        /// <param name="vector">需要放到的位置</param>
        public void Put(Vector3Int position)
        {
            Put(position.ToVector3());
        }

        #region 虚方法
        /// <summary>
        /// 摧毁当前方块
        /// </summary>
        /// <returns>摧毁掉的方块的id</returns>
        public virtual string Destroy()
        {
            _cubeRecycling.Recycling(_Object);
            _Object.gameObject.SetActive(false);
            _Object = null;

            //返回摧毁的方块的id
            return ID;
        }

        /// <summary>
        /// 摧毁当前方块，以及当前类的对象
        /// </summary>
        /// <returns>摧毁掉的方块的id</returns>
        public virtual string DestroyAndthis()
        {
            string id = Destroy();
            UnityEngine.Object.Destroy(this);

            return id;
        }

        /// <summary>
        /// 当鼠标左击到该Cube时触发，具体触发规则为，鼠标左击发射射线在碰到第一个物体后尝试将物体的对象尝试转换成ILeftClickItem对象，然后调用LeftClick方法
        /// </summary>
        public virtual void LeftClick()
        {
            //减去目标方块的耐久值
            //if (obj is Cube)
            //{
            //    Cube cube = (Cube)obj;
                
            //    //获取玩家当前耐久破坏力用当前方块减去
            //}
        }

        /// <summary>
        /// 当鼠标右击到该Cube时触发
        /// </summary>
        public virtual void RightClick()
        {
            //获取手持物品，并尝试放在玩家超这个方块相反方向且在该方块上
        }

        /// <summary>
        /// 将当前方块放置到某处，如果方块放置后有新的操作，就重写该方法
        /// </summary>
        /// <param name="vector">需要放到的位置</param>
        public virtual void Put(UnityEngine.Vector3 position)
        {
            _Object = GetCube();
            _Object.transform.position = position;

            if (PutGameObjectEvent != null)
                PutGameObjectEvent(this, position) ;
        }

        /// <summary>
        /// 如果此类不仅仅支持一个方块，重写此方法，重写后不要执行base.LoadCubeInfo
        /// </summary>
        /// <returns></returns>
        //public virtual CubeInfo[] LoadCubeInfo()
        //{

        //}
        #endregion

        #region 事件
        /// <summary>
        /// 放置物体时触发
        /// </summary>
        public event DreamExistence.Events.PutGameObject PutGameObjectEvent;
        #endregion

        #region 静态成员

        private static ObjectRecycling<UnityEngine.GameObject> _cubeRecycling;

        //所有方块的基本信息
        private static Dictionary<string, CubeInfo> _cubes = new Dictionary<string, CubeInfo>();

        /// <summary>
        /// 通过id创建方块
        /// </summary>
        /// <param name="id">方块的id</param>
        /// <returns></returns>
        //public static Cube CreateCube(string id)
        //{
        //    return new 
        //}


        public static CubeInfo GetCubeInfo(string id)
        {
            return _cubes[id];
        }

        /// <summary>
        /// 添加一个信息
        /// </summary>
        /// <param name="id"></param>
        /// <param name="info"></param>
        public static void AddCubeInfo(string id, CubeInfo info)
        {
            _cubes.Add(id, info);
        }
        #endregion
    }

    /// <summary>
    /// 方块的基本信息
    /// </summary>
    public class CubeInfo : GameObjectInfo
    {
        /// <summary>
        /// 耐久度，用于计算挖掘时间
        /// </summary>
        public int Durability { set; get; }
        /// <summary>
        /// 硬度，用于判断是否可以挖掘
        /// </summary>
        public int Hardness { set; get; }

        /// <summary>
        ///该方块的类型
        /// </summary>
        public Type CubeTpye { set; get; }
    }
}
