﻿using System;
using System.Collections.Generic;

namespace DreamExistence
{
    /// <summary>
    /// 解决方案中的大部分类均通过此类实例化，如果你的类继承了某些接口通过此类实例化对象，接口会自动生效
    /// </summary>
    public class Object : UnityEngine.Object
    {
        public Object()
        {
            InitialEvent.OnEventAssemblageEvent(this);
        }

        private static EventAssemblage<Object> _initialEvent = new EventAssemblage<Object>();
        /// <summary>
        /// 初始化该类的一些操作，用于管理对象
        /// </summary>
        public static EventAssemblage<Object> InitialEvent { get { return _initialEvent; } }
    }

    /// <summary>
    /// 一个事件集合，其中提供了便捷的事件管理
    /// </summary>
    public class EventAssemblage<T>
    {
        private List<System.Action<T>> _events;

        public EventAssemblage()
        {
            _events = new List<System.Action<T>>(1);
        }

        /// <summary>
        /// 执行委托
        /// </summary>
        /// <param name="t">委托需要的参数</param>
        public void OnEventAssemblageEvent(T t)
        {
            for (int i = 0; i < _events.Count; i++)
            {
                _events[i](t);
            }
        }

        /// <summary>
        /// 添加一个事件
        /// </summary>
        public void AddEvent(System.Action<T> eve)
        {
            this._events.Add(eve);
        }

        /// <summary>
        /// 删除一个事件
        /// </summary>
        public void RemoveEvent(System.Action<T> eve)
        {
            this._events.Remove(eve);
        }

        /// <summary>
        /// 根据给定的检索模式删除委托，此方法不能删除多播委托，此方法只删除一个相关委托
        /// </summary>
        /// <param name="eve">委托名</param>
        /// <param name="sim">要根据什么模式删除委托</param>
        public bool RemoveEvent(System.Action<T> eve, Similarity sim)
        {
            switch (sim)
            {
                case Similarity.Pointer:
                    {
                        this._events.Remove(eve);
                        return true;
                    }
                    break;
                case Similarity.Name:
                    {
                        foreach (var item in this._events)
                        {
                            if (item.Method.Name == eve.Method.Name)
                            {
                                this._events.Remove(item);
                                return true;
                            }
                        }
                    }
                    break;
                case Similarity.FullyQualifiedName:
                    {
                        string name = string.Format("{0}.{1}", eve.Method.ReflectedType, eve.Method.Name);

                        foreach (var item in this._events)
                        {
                            string nameItem = string.Format("{0}.{1}", item.Method.ReflectedType, eve.Method.Name);

                            if (name == nameItem)
                            {
                                this._events.Remove(item);
                                return true;
                            }
                        }
                    }
                    break;
                default:
                    break;
            }

            return false;
        }

        public enum Similarity
        {
            /// <summary>
            /// 内存指针
            /// </summary>
            Pointer,
            /// <summary>
            /// 委托方法名
            /// </summary>
            Name,
            /// <summary>
            /// 委托的方法的完全限定名
            /// </summary>
            FullyQualifiedName
        }
    }

    /// <summary>
    /// 所有对象管理类均继承此类
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class Manager<T>
    {
        protected Manager()
        {
            //创建一个委托
            System.Action<Object> act = null;
            act += this.Initial;
            //检查是否存在相同的委托，主要是为了防止反复实例化此类造成的问题
            Object.InitialEvent.RemoveEvent(act);
            //添加委托到InitialEvent对象
            Object.InitialEvent.AddEvent(act);
        }

        /// <summary>
        /// 继承一些特殊的接口后，实例化对象时会执行该方法
        /// </summary>
        /// <param name="obj"></param>
        protected virtual void Initial(Object obj) { }
    }
}
