﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence
{
    /// <summary>
    /// 日志文件类，游戏中出现的无法处理的异常信息均会被该类记录并保存成文件
    /// </summary>
    public class Log
    {

    }
}
