﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DreamExistence.GUI
{
    /// <summary>
    /// 包含着所有GUI的操作的类，此类可以获取所有GUI的对象
    /// </summary>
    public class GUILibraries : Manager<IGUI>
    {
        /// <summary>
        /// 储存所有的GUI对象
        /// </summary>
        private List<IGUI> _guis;

        public GUILibraries()
        {
            _guis = new List<IGUI>();
        }

        /// <summary>
        /// 继承了IGUI接口并继承过Object类后，在对象初始化时会自动执行该方法
        /// </summary>
        /// <param name="obj"></param>
        protected override void Initial(DreamExistence.Object obj)
        {
            if (obj is IGUI)
            {
                _guis.Add((IGUI)obj);
            }
        }
    }

    /// <summary>
    /// 所有GUI均继承此接口
    /// </summary>
    public interface IGUI
    {

    }
}
