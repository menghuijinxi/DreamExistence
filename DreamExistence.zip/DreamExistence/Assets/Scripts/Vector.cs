﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//该命名空间拥有基本游戏内的所有基本成员
namespace DreamExistence
{
    /// <summary>
    /// 二维向量，参数都是整形
    /// </summary>
    public struct Vector2Int
    {
        private int x, z;

        public int X { set { x = value; } get { return x; } }
        public int Z { set { z = value; } get { return z; } }

        /// <summary>
        /// 值是(0,0)
        /// </summary>
        public static Vector2Int Zero
        { get { return new Vector2Int(0, 0); } }

        public Vector2Int(int x, int z)
        {
            this.x = x;
            this.z = z;
        }

        public Vector2Int(UnityEngine.Vector2 vec)
        {
            x = (int)vec.x;
            z = (int)vec.y;
        }

        public Vector2Int(UnityEngine.Vector3 vec)
        {
            this.x = (int)vec.x;
            this.z = (int)vec.z;
        }

        public static bool operator <(Vector2Int a, Vector2Int b)
        {
            if (a.X < b.X && a.Z < b.Z)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public static bool operator >(Vector2Int a, Vector2Int b)
        {
            if (a.X > b.X && a.Z > b.Z)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator >=(Vector2Int a, Vector2Int b)
        {
            if (a > b || a == b)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator <=(Vector2Int a, Vector2Int b)
        {
            if (a < b || a == b)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static Vector2Int operator -(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.X - b.X, a.Z - b.Z);
        }

        public static Vector2Int operator /(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.X / b.X, a.Z / b.Z);
        }

        public static Vector2Int operator %(Vector2Int a, Vector2Int b)
        {
            return new Vector2Int(a.X % b.X, a.Z % b.Z);
        }

        public static Vector2Int operator -(Vector2Int a)
        {
            return new Vector2Int(-a.X, -a.Z);
        }
        
        #region 重写Object类方法
        /// <summary>
        /// 判断是不是同一个对象
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public override bool Equals(object obj)
		{
			return (obj is Vector2Int) && Equals((Vector2Int)obj);
		}
        
		public bool Equals(Vector2Int other)
		{
			return this.x == other.x && this.z == other.z;
		}
        
		public override int GetHashCode()
		{
			int hashCode = 0;
			unchecked {
				hashCode += 1000000007 * x.GetHashCode();
				hashCode += 1000000009 * z.GetHashCode();
			}
			return hashCode;
		}
        
		public static bool operator ==(Vector2Int lhs, Vector2Int rhs)
		{
			return lhs.Equals(rhs);
		}
        
		public static bool operator !=(Vector2Int lhs, Vector2Int rhs)
		{
			return !(lhs == rhs);
		}
		
		public override string ToString()
        {
            return string.Format("{0},{1}", this.X.ToString(), this.Z.ToString());
        }
        #endregion

    }

    /// <summary>
    /// 三维向量，参数都是整形
    /// </summary>
    public struct Vector3Int
    {
        private int x;
        private int y;
        private int z;

        public int X { set { x = value; } get { return x; } }
        public int Y { set { y = value; } get { return y; } }
        public int Z { set { z = value; } get { return z; } }

        /// <summary>
        /// 值是(0, 0, 0)
        /// </summary>
        public static Vector3Int Zero
        {
            get
            {
                return new Vector3Int(0, 0, 0);
            }
        }
        
        public Vector3Int(int x, int y, int z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public Vector3Int(UnityEngine.Vector3 vec)
        {
            this.x = (int)vec.x;
            this.y = (int)vec.y;
            this.z = (int)vec.z;
        }

        /// <summary>
        /// 将当前值从世界坐标转换成区块坐标
        /// </summary>
        public void ToAreaBlock()
        {
            this.x = this.x % 16;
            this.z = this.z % 16;
        }

        /// <summary>
        /// 将当前坐标转换成unity中的坐标
        /// </summary>
        /// <returns></returns>
        public UnityEngine.Vector3 ToVector3()
        {
            return new UnityEngine.Vector3(this.x, this.y, this.z);
        }

        /// <summary>
        /// 将一个世界左边转换成区域坐标并返回
        /// </summary>
        /// <param name="position">转换前的坐标</param>
        /// <returns>转换后的坐标</returns>
        public static Vector3Int WordToAreaBlock(Vector3Int position)
        {
            position.ToAreaBlock();
            return position;
        }

        /// <summary>
        /// 将当前坐标转换成unity中的坐标
        /// </summary>
        /// <param name="position">转换前的坐标</param>
        /// <returns>转换后的坐标</returns>
        public static UnityEngine.Vector3 Vector3IntToVector3(Vector3Int position)
        {
            return position.ToVector3(); ;
        }

        #region 重写Object方法
        public override bool Equals(object obj)
		{
			return (obj is Vector3Int) && Equals((Vector3Int)obj);
		}
        
		public bool Equals(Vector3Int other)
		{
			return this.x == other.x && this.y == other.y && this.z == other.z;
		}

        public override int GetHashCode()
        {
            int hashCode = 0;
            unchecked
            {
                hashCode += 1000000007 * x.GetHashCode();
                hashCode += 1000000009 * y.GetHashCode();
                hashCode += 1000000021 * z.GetHashCode();
            }
            return hashCode;
        }

        public static bool operator ==(Vector3Int lhs, Vector3Int rhs)
		{
			return lhs.Equals(rhs);
		}
        
		public static bool operator !=(Vector3Int lhs, Vector3Int rhs)
		{
			return !(lhs == rhs);
		}

        public override string ToString()
        {
            return string.Format("{0},{1},{2}", this, X.ToString(), this.Y.ToString(), this.Z.ToString());
        }
        #endregion
    }
}
