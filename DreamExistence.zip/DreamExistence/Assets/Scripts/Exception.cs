﻿using System;

namespace DreamExistence.Exceptions
{
	public class kk
	{}
}
